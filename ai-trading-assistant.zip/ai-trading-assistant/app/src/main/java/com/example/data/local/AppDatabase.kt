package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.AnalysisLogDao
import com.example.data.local.dao.TradingNoteDao
import com.example.data.local.dao.TradingRuleDao
import com.example.data.local.dao.TradingStrategyDao
import com.example.data.local.entity.AnalysisLogEntity
import com.example.data.local.entity.TradingNoteEntity
import com.example.data.local.entity.TradingRuleEntity
import com.example.data.local.entity.TradingStrategyEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        TradingStrategyEntity::class,
        TradingRuleEntity::class,
        TradingNoteEntity::class,
        AnalysisLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun strategyDao(): TradingStrategyDao
    abstract fun ruleDao(): TradingRuleDao
    abstract fun noteDao(): TradingNoteDao
    abstract fun logDao(): AnalysisLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "trading_assistant_db"
                )
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateDatabase(database)
                    }
                }
            }

            suspend fun populateDatabase(db: AppDatabase) {
                db.strategyDao().insertAll(DefaultTradingData.defaultStrategies)
                db.ruleDao().insertAll(DefaultTradingData.defaultRules)
                db.noteDao().insertAll(DefaultTradingData.defaultNotes)
            }
        }
    }
}
