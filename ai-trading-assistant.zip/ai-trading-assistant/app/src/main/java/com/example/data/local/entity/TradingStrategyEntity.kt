package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trading_strategies")
data class TradingStrategyEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val category: String,
    val timeframe: String,
    val description: String,
    val entryRules: String,
    val confirmationIndicators: String,
    val winRateEstimate: String,
    val exampleImageUri: String? = null,
    val isFavorite: Boolean = false,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
