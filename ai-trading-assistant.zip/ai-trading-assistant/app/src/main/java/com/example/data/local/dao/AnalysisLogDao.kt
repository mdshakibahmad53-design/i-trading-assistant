package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.AnalysisLogEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AnalysisLogDao {
    @Query("SELECT * FROM analysis_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<AnalysisLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AnalysisLogEntity): Long

    @Query("DELETE FROM analysis_logs WHERE id = :id")
    suspend fun deleteById(id: Int)

    @Query("DELETE FROM analysis_logs")
    suspend fun clearAll()
}
