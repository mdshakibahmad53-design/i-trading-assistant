package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = CyberCyan,
    onPrimary = Color(0xFF00364A),
    primaryContainer = CyberCyanContainer,
    onPrimaryContainer = CyberCyan,
    secondary = BullGreen,
    onSecondary = Color(0xFF00381C),
    secondaryContainer = BullGreenContainer,
    onSecondaryContainer = BullGreenLight,
    tertiary = WarningGold,
    background = TradingDarkBg,
    onBackground = TextPrimaryDark,
    surface = TradingDarkSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = TradingDarkCard,
    onSurfaceVariant = TextSecondaryDark,
    outline = Color(0xFF334155),
    error = BearRed,
    onError = Color.White
  )

private val LightColorScheme =
  lightColorScheme(
    primary = AccentBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDBEAFE),
    onPrimaryContainer = Color(0xFF1E3A8A),
    secondary = BullGreen,
    onSecondary = Color.White,
    background = TradingLightBg,
    onBackground = Color(0xFF0F172A),
    surface = TradingLightSurface,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = TradingLightCard,
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFCBD5E1),
    error = BearRed,
    onError = Color.White
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Default to sleek trading dark mode
  dynamicColor: Boolean = false, // Keep high-contrast trading colors
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

