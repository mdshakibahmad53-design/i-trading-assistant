package com.example.data.api

import android.graphics.Bitmap
import android.util.Base64
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

data class TradingAnalysisResult(
    val fullResponse: String,
    val signalType: String, // "CALL", "PUT", "WAIT", "INSIGHT"
    val confluenceScore: Int, // 0 - 100
    val rawJson: String? = null
)

class GeminiTradingService(private val customApiKey: String? = null) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private fun getResolvedApiKey(): String {
        if (!customApiKey.isNullOrBlank()) {
            return customApiKey
        }
        return try {
            BuildConfig.GEMINI_API_KEY
        } catch (_: Throwable) {
            ""
        }
    }

    /**
     * Converts a Bitmap to JPEG Base64 string for Gemini inlineData
     */
    fun bitmapToBase64(bitmap: Bitmap, quality: Int = 85): String {
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
        val bytes = outputStream.toByteArray()
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    /**
     * Analyzes trading question or chart image using user-taught knowledge base.
     */
    suspend fun analyzeTradeOrQuestion(
        userPrompt: String,
        userTaughtKnowledge: String,
        chartBitmap: Bitmap? = null
    ): Result<TradingAnalysisResult> = withContext(Dispatchers.IO) {
        try {
            val apiKey = getResolvedApiKey()
            if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                return@withContext Result.failure(
                    IllegalStateException(
                        "Gemini API Key পাওয়া যায়নি। অনুগ্রহ করে AI Studio Secrets panel অথবা Settings এ আপনার GEMINI_API_KEY সেট করুন।"
                    )
                )
            }

            val systemInstructionText = """
                আপনি একজন প্রফেশনাল 'AI Trading Assistant'। আপনি ব্যবহারকারীর ব্যক্তিগত ট্রেডিং গবেষক ও মার্কেট বিশ্লেষক। 
                ব্যবহারকারী মূলত এই প্ল্যাটফর্মে ট্রেড করেন: https://market-qx.info/en (Quotex / Binary & OTC Market)।
                
                গুরুত্বপূর্ণ নির্দেশিকা:
                ১. আপনাকে নিচে দেওয়া 'ব্যবহারকারীর শেখানো ট্রেডিং জ্ঞান ও নিয়মাবলী' (USER TAUGHT KNOWLEDGE BASE) অক্ষরে অক্ষরে মানতে হবে।
                ২. ব্যবহারকারী যে সমস্ত Strategy, Entry Rules, Risk Rules ও Notes আপনাকে শিখিয়েছেন, যেকোনো উত্তর দেওয়ার সময় সেগুলোর আলোকে বিশ্লেষণ করবেন।
                ৩. সহজ, প্রাঞ্জল ও বোধগম্য বাংলায় (সহজ ভাষায়) উত্তর দেবেন। যেখানে প্রমিত ট্রেডিং পরিভাষা প্রযোজ্য (যেমন Support, Resistance, Breakout, Wick Rejection, Pullback, Trend, CALL, PUT, OTC) সেগুলো স্বাভাবিকভাবে ব্যবহার করবেন।
                ৪. যখন কোনো চার্ট বিশ্লেষণ করতে দেওয়া হবে অথবা ট্রেড কনফার্মেশন চাওয়া হবে:
                   - সিগন্যাল টাইপ স্পষ্টভাবে নির্ধারণ করুন: [CALL / আপ ট্রেড], [PUT / ডাউন ট্রেড], অথবা [WAIT / কোনো ট্রেড নয়]।
                   - কনফ্লুয়েন্স স্কোর দিন (যেমন: ৮০% কনফ্লুয়েন্স)।
                   - ব্যবহারকারীর শেখানো নিয়মের সাথে কতগুলো শর্ত মিলল তার চেকলিস্ট দিন (যেমন: ✅ ট্রেন্ডের দিকে ট্রেড, ✅ কি-লেভেলে রিজেকশন উইক, ⚠️ রিস্ক ওয়ার্নিং)।
                   - সহজ ভাষায় ব্যাখ্যা করুন কেন এই ট্রেড নেওয়া উচিত বা উচিত নয়।
                ৫. ট্রেডিংয়ে কোনো ১০০% গ্যারান্টি নেই - সর্বদা ক্যাপিটাল রক্ষা এবং ১-২% রিস্ক রুল মনে করিয়ে দেবেন।
                
                $userTaughtKnowledge
            """.trimIndent()

            val contentsArray = JSONArray()
            val contentObj = JSONObject()
            val partsArray = JSONArray()

            // Add chart image part if present
            if (chartBitmap != null) {
                val base64Data = bitmapToBase64(chartBitmap)
                val imagePart = JSONObject().apply {
                    put("inlineData", JSONObject().apply {
                        put("mimeType", "image/jpeg")
                        put("data", base64Data)
                    })
                }
                partsArray.put(imagePart)
            }

            // Add text prompt part
            val promptPart = JSONObject().apply {
                put("text", userPrompt)
            }
            partsArray.put(promptPart)

            contentObj.put("parts", partsArray)
            contentsArray.put(contentObj)

            // System instruction
            val systemInstructionObj = JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().apply {
                        put("text", systemInstructionText)
                    })
                })
            }

            // Generation config
            val generationConfigObj = JSONObject().apply {
                put("temperature", 0.3)
                put("topP", 0.95)
                put("topK", 40)
            }

            val requestBodyJson = JSONObject().apply {
                put("contents", contentsArray)
                put("systemInstruction", systemInstructionObj)
                put("generationConfig", generationConfigObj)
            }

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val body = requestBodyJson.toString().toRequestBody(mediaType)

            // Model choice: gemini-2.5-flash for reliable multimodal vision and fast inference
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"

            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            val responseBodyString = response.body?.string()

            if (!response.isSuccessful || responseBodyString.isNullOrBlank()) {
                val errorMsg = "API Error ${response.code}: ${responseBodyString ?: "Empty response"}"
                return@withContext Result.failure(Exception(errorMsg))
            }

            val jsonResponse = JSONObject(responseBodyString)
            val candidates = jsonResponse.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                return@withContext Result.failure(Exception("মডেল থেকে কোনো উত্তর পাওয়া যায়নি।"))
            }

            val firstCandidate = candidates.getJSONObject(0)
            val content = firstCandidate.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val generatedText = if (parts != null && parts.length() > 0) {
                parts.getJSONObject(0).optString("text", "")
            } else {
                "কোনো উত্তর পাওয়া যায়নি।"
            }

            // Determine signal type & score heuristically
            val upperText = generatedText.uppercase()
            val signalType = when {
                upperText.contains("CALL") || upperText.contains("আপ ট্রেড") || upperText.contains("BUY") -> "CALL"
                upperText.contains("PUT") || upperText.contains("ডাউন ট্রেড") || upperText.contains("SELL") -> "PUT"
                upperText.contains("WAIT") || upperText.contains("ট্রেড থেকে বিরত") || upperText.contains("NO TRADE") -> "WAIT"
                else -> "INSIGHT"
            }

            // Extract confluence percentage if present, default to 75
            val regex = Regex("""(\d{1,3})\s*%\s*(?:কনফ্লুয়েন্স|confluence|সম্ভাবনা|probability)""", RegexOption.IGNORE_CASE)
            val match = regex.find(generatedText)
            val score = match?.groupValues?.getOrNull(1)?.toIntOrNull() ?: when (signalType) {
                "CALL", "PUT" -> 80
                "WAIT" -> 40
                else -> 70
            }

            Result.success(
                TradingAnalysisResult(
                    fullResponse = generatedText,
                    signalType = signalType,
                    confluenceScore = score.coerceIn(0, 100),
                    rawJson = responseBodyString
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
