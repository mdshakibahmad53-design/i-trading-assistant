package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.TradingStrategyEntity
import com.example.ui.theme.BearRed
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.TradingDarkBg
import com.example.ui.theme.TradingDarkCard
import com.example.ui.theme.TradingDarkSurface
import com.example.ui.theme.WarningGold
import com.example.ui.viewmodel.TradingViewModel

@Composable
fun StrategiesScreen(viewModel: TradingViewModel) {
    val strategies by viewModel.strategies.collectAsStateWithLifecycle()
    var showAddDialog by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(TradingDarkBg)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Surface(
                color = TradingDarkSurface,
                tonalElevation = 3.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(BullGreen.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.School,
                                    contentDescription = "Strategies",
                                    tint = BullGreen,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "AI স্ট্র্যাটেজি মেমোরি",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "${strategies.count { it.isActive }} টি সক্রিয় স্ট্র্যাটেজি শেখানো আছে",
                                    fontSize = 12.sp,
                                    color = BullGreen
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "আপনি এখানে নতুন কোনো স্ট্র্যাটেজি শেখালে AI স্বয়ংক্রিয়ভাবে তা শিখে নেবে এবং মার্কেট চার্ট এনালাইসিস করার সময় আপনার দেওয়া নিয়মগুলো প্রয়োগ করবে।",
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8),
                        lineHeight = 16.sp
                    )
                }
            }

            // Strategies List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp),
                contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(strategies, key = { it.id }) { strategy ->
                    StrategyCardItem(
                        strategy = strategy,
                        onToggleActive = { viewModel.toggleStrategyActive(strategy.id, strategy.isActive) },
                        onToggleFavorite = { viewModel.toggleStrategyFavorite(strategy.id, strategy.isFavorite) },
                        onDelete = { viewModel.deleteStrategy(strategy) }
                    )
                }
            }
        }

        // Add Strategy FAB
        FloatingActionButton(
            onClick = { showAddDialog = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("fab_add_strategy"),
            containerColor = CyberCyan,
            contentColor = Color(0xFF00364A)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add")
                Spacer(modifier = Modifier.width(6.dp))
                Text("নতুন স্ট্র্যাটেজি শেখান", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }

    // Add Strategy Dialog
    if (showAddDialog) {
        AddStrategyDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { title, category, timeframe, desc, rules, indicators, winRate ->
                viewModel.addStrategy(title, category, timeframe, desc, rules, indicators, winRate)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun StrategyCardItem(
    strategy: TradingStrategyEntity,
    onToggleActive: () -> Unit,
    onToggleFavorite: () -> Unit,
    onDelete: () -> Unit
) {
    var isExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { isExpanded = !isExpanded }
            .testTag("strategy_item_${strategy.id}"),
        colors = CardDefaults.cardColors(containerColor = TradingDarkCard),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    IconButton(onClick = onToggleFavorite, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = if (strategy.isFavorite) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "Favorite",
                            tint = if (strategy.isFavorite) WarningGold else Color(0xFF64748B)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = strategy.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color.White
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(top = 2.dp)
                        ) {
                            Text(
                                text = strategy.category,
                                fontSize = 11.sp,
                                color = CyberCyan,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = " • " + strategy.timeframe,
                                fontSize = 11.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Active status switch
                    Switch(
                        checked = strategy.isActive,
                        onCheckedChange = { onToggleActive() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF00381C),
                            checkedTrackColor = BullGreen,
                            uncheckedThumbColor = Color(0xFF64748B),
                            uncheckedTrackColor = Color(0xFF1E293B)
                        ),
                        modifier = Modifier.testTag("switch_strategy_active_${strategy.id}")
                    )

                    IconButton(onClick = { isExpanded = !isExpanded }, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = "Expand",
                            tint = Color(0xFF94A3B8)
                        )
                    }
                }
            }

            // Summary row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Speed,
                        contentDescription = "Win Rate",
                        tint = BullGreen,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "উইন রেট: ${strategy.winRateEstimate}",
                        fontSize = 12.sp,
                        color = BullGreen,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = if (strategy.isActive) "AI মেমোরিতে সক্রিয়" else "নিষ্ক্রিয়",
                    fontSize = 11.sp,
                    color = if (strategy.isActive) CyberCyan else Color(0xFF64748B)
                )
            }

            // Expanded Details
            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                ) {
                    Text(
                        text = "বিবরণ:",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp,
                        color = Color(0xFFE2E8F0)
                    )
                    Text(
                        text = strategy.description,
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8),
                        modifier = Modifier.padding(vertical = 4.dp),
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "এন্ট্রি রুলস (Rules taught to AI):",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp,
                        color = BullGreen
                    )
                    Text(
                        text = strategy.entryRules,
                        fontSize = 12.sp,
                        color = Color(0xFFF1F5F9),
                        modifier = Modifier.padding(vertical = 4.dp),
                        lineHeight = 18.sp
                    )

                    if (strategy.confirmationIndicators.isNotBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "কনফার্মেশন ইন্ডিকেটর:",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp,
                            color = CyberCyan
                        )
                        Text(
                            text = strategy.confirmationIndicators,
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8),
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = onDelete) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = BearRed, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("মুছে ফেলুন", color = BearRed, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddStrategyDialog(
    onDismiss: () -> Unit,
    onConfirm: (
        title: String,
        category: String,
        timeframe: String,
        description: String,
        entryRules: String,
        confirmationIndicators: String,
        winRateEstimate: String
    ) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Price Action") }
    var timeframe by remember { mutableStateOf("1 Min") }
    var description by remember { mutableStateOf("") }
    var entryRules by remember { mutableStateOf("") }
    var confirmationIndicators by remember { mutableStateOf("") }
    var winRateEstimate by remember { mutableStateOf("80%") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.School, contentDescription = null, tint = BullGreen)
                Spacer(modifier = Modifier.width(8.dp))
                Text("AI-কে নতুন ট্রেডিং স্ট্র্যাটেজি শেখান", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("স্ট্র্যাটেজির নাম (যেমন: S/R রিভার্সাল)") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberCyan,
                        focusedLabelColor = CyberCyan
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text("ক্যাটাগরি") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = timeframe,
                        onValueChange = { timeframe = it },
                        label = { Text("টাইমফ্রেম") },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = winRateEstimate,
                    onValueChange = { winRateEstimate = it },
                    label = { Text("আনুমানিক উইন রেট (যেমন: 85%)") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("স্ট্র্যাটেজির সংক্ষিপ্ত বিবরণ") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )

                OutlinedTextField(
                    value = entryRules,
                    onValueChange = { entryRules = it },
                    label = { Text("এন্ট্রি নিয়মাবলী (Rules AI will check)") },
                    placeholder = { Text("১. ক্যান্ডেল লেভেল স্পর্শ করবে\n২. রিজেকশন উইক হবে\n৩. নতুন ক্যান্ডেলে এন্ট্রি") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3
                )

                OutlinedTextField(
                    value = confirmationIndicators,
                    onValueChange = { confirmationIndicators = it },
                    label = { Text("ইন্ডিকেটর কনফার্মেশন (ঐচ্ছিক)") },
                    placeholder = { Text("যেমন: RSI Overbought, EMA 20 ট্রেন্ড") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && entryRules.isNotBlank()) {
                        onConfirm(title, category, timeframe, description, entryRules, confirmationIndicators, winRateEstimate)
                    }
                },
                enabled = title.isNotBlank() && entryRules.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = BullGreen, contentColor = Color(0xFF00381C))
            ) {
                Text("AI কে শিখিয়ে সংরক্ষণ করুন", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল", color = Color(0xFF94A3B8))
            }
        },
        containerColor = TradingDarkCard
    )
}
