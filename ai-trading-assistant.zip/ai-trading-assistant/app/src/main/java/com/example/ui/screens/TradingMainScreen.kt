package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.FactCheck
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.TradingDarkBg
import com.example.ui.theme.TradingDarkSurface
import com.example.ui.viewmodel.TradingViewModel

enum class TradingTab(val title: String, val icon: ImageVector, val tag: String) {
    MARKET("Market QX", Icons.Default.Public, "tab_market"),
    ASSISTANT("AI এনালাইসিস", Icons.Default.AutoAwesome, "tab_assistant"),
    STRATEGIES("স্ট্র্যাটেজি", Icons.Default.School, "tab_strategies"),
    RULES("রুলস", Icons.Default.Shield, "tab_rules"),
    CHECKLIST("চেকলিস্ট", Icons.AutoMirrored.Filled.FactCheck, "tab_checklist"),
    NOTES("নোটস", Icons.Default.Book, "tab_notes")
}

@Composable
fun TradingMainScreen(viewModel: TradingViewModel) {
    var selectedTabOrdinal by rememberSaveable { mutableIntStateOf(TradingTab.MARKET.ordinal) }
    val currentTab = TradingTab.entries[selectedTabOrdinal]

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = TradingDarkSurface,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                TradingTab.entries.forEach { tab ->
                    val isSelected = tab == currentTab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedTabOrdinal = tab.ordinal },
                        icon = {
                            Icon(
                                tab.icon,
                                contentDescription = tab.title,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontSize = 10.sp,
                                maxLines = 1
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF00364A),
                            selectedTextColor = CyberCyan,
                            indicatorColor = CyberCyan,
                            unselectedIconColor = Color(0xFF94A3B8),
                            unselectedTextColor = Color(0xFF64748B)
                        ),
                        modifier = Modifier.testTag(tab.tag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(TradingDarkBg)
        ) {
            when (currentTab) {
                TradingTab.MARKET -> MarketBrowserScreen(
                    viewModel = viewModel,
                    onNavigateToAssistant = { selectedTabOrdinal = TradingTab.ASSISTANT.ordinal }
                )
                TradingTab.ASSISTANT -> AssistantScreen(
                    viewModel = viewModel,
                    onNavigateToMarket = { selectedTabOrdinal = TradingTab.MARKET.ordinal }
                )
                TradingTab.STRATEGIES -> StrategiesScreen(
                    viewModel = viewModel
                )
                TradingTab.RULES -> RulesScreen(
                    viewModel = viewModel
                )
                TradingTab.CHECKLIST -> ConfluenceScreen(
                    viewModel = viewModel,
                    onNavigateToAssistant = { selectedTabOrdinal = TradingTab.ASSISTANT.ordinal }
                )
                TradingTab.NOTES -> NotesScreen(
                    viewModel = viewModel
                )
            }
        }
    }
}
