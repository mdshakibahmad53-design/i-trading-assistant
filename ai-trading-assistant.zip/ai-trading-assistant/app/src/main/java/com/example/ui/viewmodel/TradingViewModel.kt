package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.GeminiTradingService
import com.example.data.api.TradingAnalysisResult
import com.example.data.local.AppDatabase
import com.example.data.local.entity.AnalysisLogEntity
import com.example.data.local.entity.TradingNoteEntity
import com.example.data.local.entity.TradingRuleEntity
import com.example.data.local.entity.TradingStrategyEntity
import com.example.data.repository.TradingRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ChatMessage(
    val id: String = System.currentTimeMillis().toString() + "_" + (0..1000).random(),
    val sender: MessageSender,
    val text: String,
    val imageBitmap: Bitmap? = null,
    val signalType: String? = null,
    val confluenceScore: Int? = null,
    val timestamp: Long = System.currentTimeMillis()
)

enum class MessageSender {
    USER, AI, SYSTEM
}

class TradingViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application, viewModelScope)
    val repository = TradingRepository(database)
    private var geminiService = GeminiTradingService()

    // Persistent Room Flows
    val strategies: StateFlow<List<TradingStrategyEntity>> = repository.allStrategies
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val rules: StateFlow<List<TradingRuleEntity>> = repository.allRules
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notes: StateFlow<List<TradingNoteEntity>> = repository.allNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val logs: StateFlow<List<AnalysisLogEntity>> = repository.allLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Chat Messages
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = MessageSender.AI,
                text = "স্বাগতম! আমি আপনার 'AI Trading Assistant'। আপনি আমাকে ধীরে ধীরে যেসমস্ত স্ট্র্যাটেজি, ক্যান্ডেলস্টিক নিয়ম এবং রিস্ক ম্যানেজমেন্ট পলিসি শেখাবেন, আমি ঠিক সেই অনুযায়ী https://market-qx.info/en প্ল্যাটফর্মের মার্কেট বিশ্লেষণ করব।\n\nআপনি চাইলে নিচের 'Market QX' ট্যাব থেকে লাইভ চার্ট স্ক্রিনশট নিয়ে এখানে বিশ্লেষণ করাতে পারেন অথবা যেকোনো ট্রেডিং প্রশ্ন জিজ্ঞেস করতে পারেন!"
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _pendingChartBitmap = MutableStateFlow<Bitmap?>(null)
    val pendingChartBitmap: StateFlow<Bitmap?> = _pendingChartBitmap.asStateFlow()

    private val _customApiKey = MutableStateFlow("")
    val customApiKey: StateFlow<String> = _customApiKey.asStateFlow()

    private val _currentMarketUrl = MutableStateFlow("https://market-qx.info/en")
    val currentMarketUrl: StateFlow<String> = _currentMarketUrl.asStateFlow()

    // Pre-trade checklist items state
    private val _checklistStates = MutableStateFlow<Map<Int, Boolean>>(emptyMap())
    val checklistStates: StateFlow<Map<Int, Boolean>> = _checklistStates.asStateFlow()

    init {
        viewModelScope.launch {
            repository.restoreDefaultsIfEmpty()
        }
    }

    fun setPendingChartBitmap(bitmap: Bitmap?) {
        _pendingChartBitmap.value = bitmap
    }

    fun setCustomApiKey(key: String) {
        _customApiKey.value = key
        geminiService = GeminiTradingService(key)
    }

    fun setMarketUrl(url: String) {
        _currentMarketUrl.value = url
    }

    fun toggleChecklistItem(ruleId: Int) {
        val current = _checklistStates.value.toMutableMap()
        current[ruleId] = !(current[ruleId] ?: false)
        _checklistStates.value = current
    }

    fun resetChecklist() {
        _checklistStates.value = emptyMap()
    }

    fun sendUserMessage(text: String, chartBitmap: Bitmap? = _pendingChartBitmap.value) {
        if (text.isBlank() && chartBitmap == null) return

        val userMsg = ChatMessage(
            sender = MessageSender.USER,
            text = text,
            imageBitmap = chartBitmap
        )
        _chatMessages.value = _chatMessages.value + userMsg
        _pendingChartBitmap.value = null // clear pending attachment

        _isAnalyzing.value = true

        viewModelScope.launch {
            val knowledge = repository.buildUserTaughtTradingKnowledge()
            val result = geminiService.analyzeTradeOrQuestion(
                userPrompt = text.ifBlank { "অনুগ্রহ করে সংযুক্ত চার্টটি আমার শেখানো স্ট্র্যাটেজি ও রুলস অনুযায়ী বিশ্লেষণ করে সিগন্যাল ও কনফ্লুয়েন্স দিন।" },
                userTaughtKnowledge = knowledge,
                chartBitmap = chartBitmap
            )

            _isAnalyzing.value = false

            result.onSuccess { analysis ->
                val aiMsg = ChatMessage(
                    sender = MessageSender.AI,
                    text = analysis.fullResponse,
                    signalType = analysis.signalType,
                    confluenceScore = analysis.confluenceScore
                )
                _chatMessages.value = _chatMessages.value + aiMsg

                // Persist to analysis log
                repository.insertLog(
                    AnalysisLogEntity(
                        query = text,
                        response = analysis.fullResponse,
                        signalType = analysis.signalType,
                        confluenceScore = analysis.confluenceScore
                    )
                )
            }.onFailure { error ->
                val errorMsg = ChatMessage(
                    sender = MessageSender.AI,
                    text = "দুঃখিত, বিশ্লেষণে সমস্যা হয়েছে:\n${error.localizedMessage ?: "অজ্ঞাত সমস্যা"}\n\nঅনুগ্রহ করে ইন্টারনেট কানেকশন বা API Key যাচাই করুন।"
                )
                _chatMessages.value = _chatMessages.value + errorMsg
            }
        }
    }

    // Strategy actions
    fun addStrategy(
        title: String,
        category: String,
        timeframe: String,
        description: String,
        entryRules: String,
        confirmationIndicators: String,
        winRateEstimate: String
    ) {
        viewModelScope.launch {
            repository.insertStrategy(
                TradingStrategyEntity(
                    title = title,
                    category = category,
                    timeframe = timeframe,
                    description = description,
                    entryRules = entryRules,
                    confirmationIndicators = confirmationIndicators,
                    winRateEstimate = winRateEstimate,
                    isActive = true
                )
            )
        }
    }

    fun toggleStrategyActive(id: Int, currentActive: Boolean) {
        viewModelScope.launch {
            repository.toggleStrategyActive(id, !currentActive)
        }
    }

    fun toggleStrategyFavorite(id: Int, currentFavorite: Boolean) {
        viewModelScope.launch {
            repository.toggleStrategyFavorite(id, !currentFavorite)
        }
    }

    fun deleteStrategy(strategy: TradingStrategyEntity) {
        viewModelScope.launch {
            repository.deleteStrategy(strategy)
        }
    }

    // Rule actions
    fun addRule(
        title: String,
        description: String,
        category: String,
        priority: String
    ) {
        viewModelScope.launch {
            repository.insertRule(
                TradingRuleEntity(
                    title = title,
                    description = description,
                    category = category,
                    priority = priority,
                    isActive = true
                )
            )
        }
    }

    fun toggleRuleActive(id: Int, currentActive: Boolean) {
        viewModelScope.launch {
            repository.toggleRuleActive(id, !currentActive)
        }
    }

    fun deleteRule(rule: TradingRuleEntity) {
        viewModelScope.launch {
            repository.deleteRule(rule)
        }
    }

    // Note actions
    fun addNote(title: String, category: String, content: String) {
        viewModelScope.launch {
            repository.insertNote(
                TradingNoteEntity(
                    title = title,
                    category = category,
                    content = content
                )
            )
        }
    }

    fun deleteNote(note: TradingNoteEntity) {
        viewModelScope.launch {
            repository.deleteNote(note)
        }
    }

    fun clearChat() {
        _chatMessages.value = listOf(
            ChatMessage(
                sender = MessageSender.AI,
                text = "চ্যাট হিস্ট্রি রিসেট করা হয়েছে। আপনি কি শিখাতে চান বা মার্কেট সম্পর্কে কি জানতে চান বলুন!"
            )
        )
    }

    fun restoreDefaultKnowledge() {
        viewModelScope.launch {
            repository.restoreDefaultsIfEmpty()
        }
    }
}
