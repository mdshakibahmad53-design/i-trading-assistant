package com.example.data.local

import com.example.data.local.entity.TradingNoteEntity
import com.example.data.local.entity.TradingRuleEntity
import com.example.data.local.entity.TradingStrategyEntity

object DefaultTradingData {

    val defaultStrategies = listOf(
        TradingStrategyEntity(
            title = "S/R Level Rejection (সাপোর্ট ও রেজিস্ট্যান্স রিভার্সাল)",
            category = "Price Action",
            timeframe = "1 Min (1 Minute Expiry)",
            description = "মার্কেট যখন কোনো স্ট্রং সাপোর্ট অথবা রেজিস্ট্যান্স লেভেলে পৌঁছে বড় উইক (Wick) দিয়ে রিজেকশন দেখায়, তখন বিপরীত দিকে রিভার্সাল ট্রেড নেওয়া হয়।",
            entryRules = "১. পূর্বের স্ট্রং সাপোর্ট বা রেজিস্ট্যান্স লাইন অথবা রাউন্ড নম্বর (যেমন .000, .500) চিহ্নিত করুন।\n২. ক্যান্ডেলস্টিক লেভেলটিতে স্পর্শ করার পর যদি দ্রুত রিজেকশন নিয়ে লং উইক তৈরি করে।\n৩. ক্যান্ডেল ক্লোজ হওয়ার পর পরবর্তী ক্যান্ডেলের শুরুতে রিভার্সাল ডিরেকশনে ট্রেড প্লেস করুন (সাপোর্টে CALL, রেজিস্ট্যান্সে PUT)।\n৪. কখনো স্ট্রং ট্রেন্ডের মাঝে সরাসরি রিভার্সাল নিবেন না; কনসোলিডেশন বা রেঞ্জিং মার্কেটে এটি সবচেয়ে নিখুঁত কাজ করে।",
            confirmationIndicators = "RSI Overbought (>70) বা Oversold (<30) ডাইভারজেন্স, Bollinger Bands আউটার রিজেকশন",
            winRateEstimate = "84%",
            isFavorite = true,
            isActive = true
        ),
        TradingStrategyEntity(
            title = "EMA 9 & 21 Trend Crossover (ট্রেন্ড ফলোয়িং ট্রেড)",
            category = "Indicators",
            timeframe = "1-2 Min Expiry",
            description = "স্ট্রং ট্রেন্ডিং মার্কেটে ট্রেন্ডের সাথে ট্রেড নেওয়ার জন্য এক্সপোনেনশিয়াল মুভিং এভারেজ (EMA) ক্রসওভার ও পুলব্যাক স্ট্র্যাটেজি।",
            entryRules = "১. চার্টে EMA 9 এবং EMA 21 সেট করুন।\n২. যখন EMA 9 নিচ থেকে উপরে EMA 21 কে ক্রস করে, তখন ট্রেন্ড বুলিশ।\n৩. সরাসরি ক্রসে ট্রেড না নিয়ে ক্যান্ডেল EMA 9 এ রিটেস্ট/পুলব্যাক হওয়া পর্যন্ত অপেক্ষা করুন।\n৪. বুলিশ পিনবার বা এঙ্গালফিং ক্যান্ডেল দেখলেই ১-২ মিনিটের জন্য CALL ট্রেড নিন।\n৫. ডাউনট্রেন্ডের ক্ষেত্রে বিপরীত (EMA 9 নিচে ক্রস করলে বিয়ারিশ পুলব্যাকে PUT)।",
            confirmationIndicators = "EMA 9 > EMA 21 (Uptrend), MACD হিস্টোগ্রাম গ্রিন ও পজিটিভ",
            winRateEstimate = "79%",
            isFavorite = true,
            isActive = true
        ),
        TradingStrategyEntity(
            title = "OTC Market Momentum & Gap Trap (OTC স্পেশাল স্ট্র্যাটেজি)",
            category = "OTC Special",
            timeframe = "1 Min Expiry",
            description = "Quotex (market-qx.info) OTC মার্কেটে সাধারণ অ্যালগরিদমিক গ্যাপ ও ক্যান্ডেল মোমেন্টাম শনাক্ত করার কৌশল।",
            entryRules = "১. OTC মার্কেটে পর পর ৩টি স্ট্রং মোমেন্টাম ক্যান্ডেল তৈরি হলে ট্রেন্ড সহজে থামে না।\n২. যদি নতুন ক্যান্ডেল খোলার সময় কোনো ছোট গ্যাপ তৈরি হয় এবং গ্যাপটি ট্রেন্ডের দিকে হয়, তবে ট্রেন্ড কন্টিনিউ করে।\n৩. ওটিসি মার্কেটে লেভেল ব্রেকআউট বেশি হয়, তাই রিভার্সালের চেয়ে ব্রেকআউট রিটেস্টে ট্রেড করা নিরাপদ।\n৪. ওটিসি মার্কেটে নিউজ ইমপ্যাক্ট নেই, তাই অ্যালগরিদমের প্যাটার্ন ফলো করুন।",
            confirmationIndicators = "Consecutive momentum candles, Stochastic > 50 for bullish continuation",
            winRateEstimate = "81%",
            isFavorite = false,
            isActive = true
        ),
        TradingStrategyEntity(
            title = "False Breakout Trap (ফেক ব্রেকআউট ট্র্যাপ)",
            category = "Price Action",
            timeframe = "1 Min Expiry",
            description = "মার্কেট যখন সাপোর্ট বা রেজিস্ট্যান্স ব্রেক করে রিটেইল ট্রেডারদের ফাঁদে ফেলে দ্রুত ভেতরে ফেরত আসে।",
            entryRules = "১. লেভেল ব্রেক করা ক্যান্ডেলটির বডি ছোট এবং অনেক বড় উইক বাইরে থাকে।\n২. পরবর্তী ক্যান্ডেলটি আবার রেঞ্জের ভেতরে স্ট্রংলি ক্লোজ হয়।\n৩. এই ট্র্যাপ নিশ্চিত হলে বিপরীত দিকে ১ মিনিটের ট্রেড নিন।",
            confirmationIndicators = "Volume spike followed by sharp reversal, False breakout wick",
            winRateEstimate = "86%",
            isFavorite = true,
            isActive = true
        )
    )

    val defaultRules = listOf(
        TradingRuleEntity(
            title = "প্রতি ট্রেডে সর্বোচ্চ ১% থেকে ২% রিস্ক",
            description = "অ্যাকাউন্টের মোট ব্যালেন্সের ১%-২% এর বেশি কখনো একটি সিঙ্গেল ট্রেডে ইনভেস্ট করবেন না। ক্যাপিটাল রক্ষা করাই প্রথম ট্রেডিং নিয়ম।",
            category = "RISK_MANAGEMENT",
            priority = "STRICT_MANDATORY",
            isActive = true
        ),
        TradingRuleEntity(
            title = "দিনে সর্বোচ্চ ২ টি লস হলে ট্রেডিং বন্ধ",
            description = "টানা ২টি লস হলে সাথে সাথে মার্কেট বন্ধ করে দিন। রিভেঞ্জ ট্রেডিং (Revenge Trading) পুরো ব্যালেন্স জিরো করে দেয়।",
            category = "EMOTION_CONTROL",
            priority = "STRICT_MANDATORY",
            isActive = true
        ),
        TradingRuleEntity(
            title = "কখনো ট্রেন্ডের বিপরীতে ব্লাইন্ডলি ট্রেড নয়",
            description = "Trend is your friend! স্ট্রং আপট্রেন্ডে কখনোই পুট (PUT) বা ডাউনট্রেন্ডে কল (CALL) খুঁজবেন না যতক্ষণ না মেজর কি-লেভেল কনফার্মেশন আসে।",
            category = "ENTRY_FILTER",
            priority = "STRICT_MANDATORY",
            isActive = true
        ),
        TradingRuleEntity(
            title = "মার্টিনগেল (Martingale) সর্বোচ্চ ১ স্টেপ",
            description = "লস রিকভারির জন্য কখনই ২ স্টেপের বেশি মার্টিনগেল ব্যবহার করবেন না। মার্টিনগেল শুধুমাত্র উচ্চ কনফ্লুয়েন্স সেটাপেই প্রযোজ্য।",
            category = "RISK_MANAGEMENT",
            priority = "IMPORTANT",
            isActive = true
        ),
        TradingRuleEntity(
            title = "ট্রেড এন্ট্রি ক্যান্ডেলের প্রথম ৫ সেকেন্ডের মধ্যে",
            description = "দেরিতে এন্ট্রি নিলে খারাপ প্রাইস পজিশনে ট্রেড প্লেস হয় এবং উইন হলেও ওটিসি মার্কেটে লস হতে পারে। সঠিক ওপেনিং প্রাইসে এন্ট্রি নিন।",
            category = "ENTRY_FILTER",
            priority = "IMPORTANT",
            isActive = true
        )
    )

    val defaultNotes = listOf(
        TradingNoteEntity(
            title = "ক্যান্ডেলস্টিক সাইকোলজি: পিনবার ও উইকের রহস্য",
            category = "Candlestick Psychology",
            content = "ক্যান্ডেলের উপরের উইক (Upper Wick) মানে সেলারদের চাপ এবং নিচের উইক (Lower Wick) মানে বায়ারদের চাপ। যখন কোনো সাপোর্ট জোনে বিশাল নিচের উইক তৈরি হয়, তার অর্থ হলো সেলাররা নিচে নামাতে চেয়েছিল কিন্তু বায়াররা অনেক শক্তিশালী হয়ে প্রাইস উপরে তুলে দিয়েছে। এর পরবর্তী ক্যান্ডেলে বায়ারদের জয় হওয়ার সম্ভাবনা ৮০%+"
        ),
        TradingNoteEntity(
            title = "Quotex (market-qx.info) OTC মার্কেটের স্বভাব",
            category = "Market Structure",
            content = "ওটিসি (OTC) হলো ব্রোকারের ইন্টারনাল কোটেশন। সাধারণ কারেন্সি পেয়ারে নিউজ ইমপ্যাক্ট থাকলেও OTC তে তা থাকে না। OTC মার্কেটে ক্যান্ডেল মোমেন্টাম অনেক দীর্ঘস্থায়ী হয় এবং গোল নম্বর (Round Numbers যেমন .00, .50) খুব সুন্দর রেসপেক্ট করে। সর্বদা ট্রেন্ড ও গোল নম্বর মেলান।"
        ),
        TradingNoteEntity(
            title = "ট্রেডারদের মাইন্ডসেট ও ডিসিপ্লিন",
            category = "Daily Lessons",
            content = "ট্রেডিং হলো ৮০% সাইকোলজি এবং ২০% স্ট্র্যাটেজি। লস হলে রাগ না হয়ে মেনে নিন, কারণ এটি ব্যবসার অংশ। লাভ হলে অতিরিক্ত আত্মবিশ্বাসী হয়ে বড় রিস্ক নেওয়া যাবে না। প্রতিদিনের টার্গেট পূরণ হলে অ্যাপ ও মার্কেট বন্ধ রাখুন।"
        )
    )
}
