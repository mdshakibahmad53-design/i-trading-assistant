package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trading_rules")
data class TradingRuleEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val description: String,
    val category: String, // "RISK_MANAGEMENT", "ENTRY_FILTER", "EMOTION_CONTROL", "OTC_MARKET"
    val priority: String, // "STRICT_MANDATORY", "IMPORTANT", "GENERAL"
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
