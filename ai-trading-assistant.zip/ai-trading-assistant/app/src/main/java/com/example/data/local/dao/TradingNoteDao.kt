package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.TradingNoteEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TradingNoteDao {
    @Query("SELECT * FROM trading_notes ORDER BY id DESC")
    fun getAllNotes(): Flow<List<TradingNoteEntity>>

    @Query("SELECT * FROM trading_notes")
    suspend fun getAllNotesSync(): List<TradingNoteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: TradingNoteEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(notes: List<TradingNoteEntity>)

    @Update
    suspend fun updateNote(note: TradingNoteEntity)

    @Delete
    suspend fun deleteNote(note: TradingNoteEntity)

    @Query("DELETE FROM trading_notes WHERE id = :id")
    suspend fun deleteById(id: Int)
}
