package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.DefaultTradingData
import com.example.data.local.entity.AnalysisLogEntity
import com.example.data.local.entity.TradingNoteEntity
import com.example.data.local.entity.TradingRuleEntity
import com.example.data.local.entity.TradingStrategyEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class TradingRepository(private val database: AppDatabase) {

    val allStrategies: Flow<List<TradingStrategyEntity>> = database.strategyDao().getAllStrategies()
    val allRules: Flow<List<TradingRuleEntity>> = database.ruleDao().getAllRules()
    val allNotes: Flow<List<TradingNoteEntity>> = database.noteDao().getAllNotes()
    val allLogs: Flow<List<AnalysisLogEntity>> = database.logDao().getAllLogs()

    suspend fun insertStrategy(strategy: TradingStrategyEntity) = withContext(Dispatchers.IO) {
        database.strategyDao().insertStrategy(strategy)
    }

    suspend fun updateStrategy(strategy: TradingStrategyEntity) = withContext(Dispatchers.IO) {
        database.strategyDao().updateStrategy(strategy)
    }

    suspend fun toggleStrategyActive(id: Int, isActive: Boolean) = withContext(Dispatchers.IO) {
        database.strategyDao().updateActiveStatus(id, isActive)
    }

    suspend fun toggleStrategyFavorite(id: Int, isFavorite: Boolean) = withContext(Dispatchers.IO) {
        database.strategyDao().updateFavoriteStatus(id, isFavorite)
    }

    suspend fun deleteStrategy(strategy: TradingStrategyEntity) = withContext(Dispatchers.IO) {
        database.strategyDao().deleteStrategy(strategy)
    }

    suspend fun insertRule(rule: TradingRuleEntity) = withContext(Dispatchers.IO) {
        database.ruleDao().insertRule(rule)
    }

    suspend fun updateRule(rule: TradingRuleEntity) = withContext(Dispatchers.IO) {
        database.ruleDao().updateRule(rule)
    }

    suspend fun toggleRuleActive(id: Int, isActive: Boolean) = withContext(Dispatchers.IO) {
        database.ruleDao().updateActiveStatus(id, isActive)
    }

    suspend fun deleteRule(rule: TradingRuleEntity) = withContext(Dispatchers.IO) {
        database.ruleDao().deleteRule(rule)
    }

    suspend fun insertNote(note: TradingNoteEntity) = withContext(Dispatchers.IO) {
        database.noteDao().insertNote(note)
    }

    suspend fun updateNote(note: TradingNoteEntity) = withContext(Dispatchers.IO) {
        database.noteDao().updateNote(note)
    }

    suspend fun deleteNote(note: TradingNoteEntity) = withContext(Dispatchers.IO) {
        database.noteDao().deleteNote(note)
    }

    suspend fun insertLog(log: AnalysisLogEntity) = withContext(Dispatchers.IO) {
        database.logDao().insertLog(log)
    }

    suspend fun clearLogs() = withContext(Dispatchers.IO) {
        database.logDao().clearAll()
    }

    suspend fun restoreDefaultsIfEmpty() = withContext(Dispatchers.IO) {
        val activeStrategies = database.strategyDao().getActiveStrategies()
        if (activeStrategies.isEmpty()) {
            database.strategyDao().insertAll(DefaultTradingData.defaultStrategies)
            database.ruleDao().insertAll(DefaultTradingData.defaultRules)
            database.noteDao().insertAll(DefaultTradingData.defaultNotes)
        }
    }

    /**
     * Builds full context string containing all user-taught trading strategies,
     * golden rules, risk management policies, and notes for Gemini AI.
     */
    suspend fun buildUserTaughtTradingKnowledge(): String = withContext(Dispatchers.IO) {
        val strategies = database.strategyDao().getActiveStrategies()
        val rules = database.ruleDao().getActiveRules()
        val notes = database.noteDao().getAllNotesSync()

        val sb = StringBuilder()
        sb.append("=== ব্যবহারকারীর শেখানো ট্রেডিং জ্ঞান ও নিয়মাবলী (USER TAUGHT KNOWLEDGE BASE) ===\n")
        sb.append("ওয়েবসাইট প্ল্যাটফর্ম: https://market-qx.info/en (Quotex / Binary Options Trading)\n\n")

        sb.append("--- ১. সক্রিয় ট্রেডিং স্ট্র্যাটেজি ও নিয়মসমূহ (ACTIVE STRATEGIES) ---\n")
        if (strategies.isEmpty()) {
            sb.append("(এখনো কোনো কাস্টম স্ট্র্যাটেজি যোগ করা হয়নি, সাধারণ প্রাইস অ্যাকশন ব্যবহার করুন)\n")
        } else {
            strategies.forEachIndexed { index, s ->
                sb.append("[স্ট্র্যাটেজি #${index + 1}: ${s.title}]\n")
                sb.append("ক্যাটাগরি: ${s.category} | টাইমফ্রেম/এক্সপায়ারি: ${s.timeframe} | আনুমানিক উইন-রেট: ${s.winRateEstimate}\n")
                sb.append("বিবরণ: ${s.description}\n")
                sb.append("এন্ট্রি রুলস:\n${s.entryRules}\n")
                if (s.confirmationIndicators.isNotBlank()) {
                    sb.append("কনফার্মেশন ইন্ডিকেটর: ${s.confirmationIndicators}\n")
                }
                sb.append("\n")
            }
        }

        sb.append("--- ২. বাধ্যতামূলক রিস্ক ও ট্রেডিং রুলস (STRICT RULES & RISK MANAGEMENT) ---\n")
        if (rules.isEmpty()) {
            sb.append("(রিস্ক ম্যানেজমেন্ট রুলস: প্রতি ট্রেডে সর্বোচ্চ ১-২% ব্যালেন্স ব্যবহার করুন)\n")
        } else {
            rules.forEachIndexed { index, r ->
                sb.append("[নিয়ম #${index + 1}] (${r.priority} | ${r.category}): ${r.title}\n")
                sb.append("বিস্তারিত: ${r.description}\n\n")
            }
        }

        sb.append("--- ৩. ট্রেডিং নোটস ও ক্যান্ডেলস্টিক সাইকোলজি (NOTES & MARKET PSYCHOLOGY) ---\n")
        notes.take(10).forEachIndexed { index, n ->
            sb.append("[নোট #${index + 1}: ${n.title}] (${n.category})\n")
            sb.append("${n.content}\n\n")
        }

        sb.append("=========================================================================\n")
        sb.toString()
    }
}
