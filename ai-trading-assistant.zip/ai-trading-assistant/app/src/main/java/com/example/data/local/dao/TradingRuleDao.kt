package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.TradingRuleEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TradingRuleDao {
    @Query("SELECT * FROM trading_rules ORDER BY priority ASC, id DESC")
    fun getAllRules(): Flow<List<TradingRuleEntity>>

    @Query("SELECT * FROM trading_rules WHERE isActive = 1")
    suspend fun getActiveRules(): List<TradingRuleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRule(rule: TradingRuleEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(rules: List<TradingRuleEntity>)

    @Update
    suspend fun updateRule(rule: TradingRuleEntity)

    @Query("UPDATE trading_rules SET isActive = :isActive WHERE id = :id")
    suspend fun updateActiveStatus(id: Int, isActive: Boolean)

    @Delete
    suspend fun deleteRule(rule: TradingRuleEntity)

    @Query("DELETE FROM trading_rules WHERE id = :id")
    suspend fun deleteById(id: Int)
}
