package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.TradingStrategyEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TradingStrategyDao {
    @Query("SELECT * FROM trading_strategies ORDER BY isFavorite DESC, id DESC")
    fun getAllStrategies(): Flow<List<TradingStrategyEntity>>

    @Query("SELECT * FROM trading_strategies WHERE isActive = 1")
    suspend fun getActiveStrategies(): List<TradingStrategyEntity>

    @Query("SELECT * FROM trading_strategies WHERE id = :id")
    suspend fun getStrategyById(id: Int): TradingStrategyEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStrategy(strategy: TradingStrategyEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(strategies: List<TradingStrategyEntity>)

    @Update
    suspend fun updateStrategy(strategy: TradingStrategyEntity)

    @Query("UPDATE trading_strategies SET isActive = :isActive WHERE id = :id")
    suspend fun updateActiveStatus(id: Int, isActive: Boolean)

    @Query("UPDATE trading_strategies SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavoriteStatus(id: Int, isFavorite: Boolean)

    @Delete
    suspend fun deleteStrategy(strategy: TradingStrategyEntity)

    @Query("DELETE FROM trading_strategies WHERE id = :id")
    suspend fun deleteById(id: Int)
}
