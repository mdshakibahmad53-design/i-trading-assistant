package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Trading Theme Colors
val TradingDarkBg = Color(0xFF080D1A)
val TradingDarkSurface = Color(0xFF0F172A)
val TradingDarkCard = Color(0xFF1E293B)
val TradingDarkCardElevated = Color(0xFF27354E)

val BullGreen = Color(0xFF00E676)
val BullGreenLight = Color(0xFF69F0AE)
val BullGreenContainer = Color(0xFF00381C)

val BearRed = Color(0xFFFF5252)
val BearRedLight = Color(0xFFFF8A80)
val BearRedContainer = Color(0xFF4A0E12)

val CyberCyan = Color(0xFF00D2FF)
val CyberCyanContainer = Color(0xFF00364A)

val WarningGold = Color(0xFFFFD166)
val TextPrimaryDark = Color(0xFFF1F5F9)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextMutedDark = Color(0xFF64748B)

val AccentPurple = Color(0xFF8B5CF6)
val AccentBlue = Color(0xFF3B82F6)

// Light Theme Fallbacks (though trading apps shine best in dark)
val TradingLightBg = Color(0xFFF8FAFC)
val TradingLightSurface = Color(0xFFFFFFFF)
val TradingLightCard = Color(0xFFF1F5F9)

