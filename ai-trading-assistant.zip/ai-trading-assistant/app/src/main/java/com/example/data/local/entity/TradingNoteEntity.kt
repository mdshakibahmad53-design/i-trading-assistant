package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trading_notes")
data class TradingNoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val category: String, // "Candlestick Psychology", "Chart Patterns", "Market Structure", "Trading Journal", "Daily Lessons"
    val content: String,
    val imageUri: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
