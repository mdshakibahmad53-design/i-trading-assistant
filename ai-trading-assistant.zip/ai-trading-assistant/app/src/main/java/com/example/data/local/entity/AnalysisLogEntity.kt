package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "analysis_logs")
data class AnalysisLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val query: String,
    val response: String,
    val signalType: String, // "CALL", "PUT", "WAIT", "INSIGHT"
    val confluenceScore: Int, // 0 - 100
    val chartImageUri: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)
