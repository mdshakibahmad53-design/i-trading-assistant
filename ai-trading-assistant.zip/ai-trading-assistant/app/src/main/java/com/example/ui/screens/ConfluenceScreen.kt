package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.FactCheck
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.BearRed
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.TradingDarkBg
import com.example.ui.theme.TradingDarkCard
import com.example.ui.theme.TradingDarkSurface
import com.example.ui.theme.WarningGold
import com.example.ui.viewmodel.TradingViewModel

@Composable
fun ConfluenceScreen(
    viewModel: TradingViewModel,
    onNavigateToAssistant: () -> Unit
) {
    val rules by viewModel.rules.collectAsStateWithLifecycle()
    val checklistStates by viewModel.checklistStates.collectAsStateWithLifecycle()

    val activeRules = remember(rules) { rules.filter { it.isActive } }

    val checkedCount by remember(activeRules, checklistStates) {
        derivedStateOf {
            activeRules.count { checklistStates[it.id] == true }
        }
    }

    val scorePercentage by remember(activeRules, checkedCount) {
        derivedStateOf {
            if (activeRules.isEmpty()) 100
            else ((checkedCount.toFloat() / activeRules.size) * 100).toInt()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TradingDarkBg)
    ) {
        // Top Header
        Surface(
            color = TradingDarkSurface,
            tonalElevation = 3.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(CyberCyan.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.FactCheck,
                                contentDescription = "Checklist",
                                tint = CyberCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "ট্রেড এন্ট্রির পূর্ব চেকলিস্ট",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "মার্কেট-qx.info তে ট্রেড নেওয়ার আগে যাচাই করুন",
                                fontSize = 11.sp,
                                color = CyberCyan
                            )
                        }
                    }

                    IconButton(
                        onClick = { viewModel.resetChecklist() },
                        modifier = Modifier.testTag("btn_reset_checklist")
                    ) {
                        Icon(
                            Icons.Default.Refresh,
                            contentDescription = "রিসেট",
                            tint = Color(0xFF94A3B8)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Score Meter Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = TradingDarkCard),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "কনফ্লুয়েন্স স্কোর:",
                                fontSize = 13.sp,
                                color = Color(0xFFCBD5E1)
                            )
                            val scoreColor = when {
                                scorePercentage >= 80 -> BullGreen
                                scorePercentage >= 50 -> WarningGold
                                else -> BearRed
                            }
                            Text(
                                text = "$scorePercentage% ($checkedCount / ${activeRules.size})",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = scoreColor
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { if (activeRules.isEmpty()) 1f else checkedCount.toFloat() / activeRules.size },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = when {
                                scorePercentage >= 80 -> BullGreen
                                scorePercentage >= 50 -> WarningGold
                                else -> BearRed
                            },
                            trackColor = Color(0xFF1E293B)
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        val advice = when {
                            scorePercentage >= 80 -> "✅ উচ্চ সম্ভাবনাময় সেটআপ (High Probability) - আপনার শেখানো প্রায় সকল নিয়ম পূরণ হয়েছে।"
                            scorePercentage >= 50 -> "⚠️ মাঝারি ঝুঁকি (Moderate Risk) - কিছু জরুরি নিয়ম এখনো মেলেনি, নিশ্চিত কনফার্মেশন নিন।"
                            else -> "🛑 অতিরিক্ত ঝুঁকি (High Risk / Avoid) - নিয়ম না মিললে অযথা ব্যালেন্স ঝুঁকিতে ফেলবেন না।"
                        }
                        Text(
                            text = advice,
                            fontSize = 11.sp,
                            color = when {
                                scorePercentage >= 80 -> BullGreen
                                scorePercentage >= 50 -> WarningGold
                                else -> BearRed
                            },
                            fontWeight = FontWeight.Medium,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }

        // Checklist Items List
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 14.dp),
            contentPadding = PaddingValues(top = 10.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(activeRules, key = { it.id }) { rule ->
                val isChecked = checklistStates[rule.id] == true

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isChecked) Color(0xFF132238) else TradingDarkCard
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = isChecked,
                            onCheckedChange = { viewModel.toggleChecklistItem(rule.id) },
                            colors = CheckboxDefaults.colors(
                                checkedColor = BullGreen,
                                checkmarkColor = Color(0xFF00381C),
                                uncheckedColor = Color(0xFF64748B)
                            ),
                            modifier = Modifier.testTag("check_rule_${rule.id}")
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = rule.title,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isChecked) BullGreen else Color.White
                            )
                            Text(
                                text = rule.description,
                                fontSize = 11.sp,
                                color = Color(0xFF94A3B8),
                                modifier = Modifier.padding(top = 2.dp),
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }
        }

        // Ask AI Button
        Surface(
            color = TradingDarkSurface,
            tonalElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                Button(
                    onClick = {
                        val prompt = "আমি বর্তমানে চার্টে একটি ট্রেড বিবেচনা করছি। চেকলিস্ট স্কোর: $scorePercentage% ($checkedCount/${activeRules.size} নিয়ম পূরণ হয়েছে)। অনুগ্রহ করে আমার শেখানো নিয়ম অনুযায়ী আমাকে চূড়ান্ত মতামত ও রিস্ক অ্যানালাইসিস দিন।"
                        viewModel.sendUserMessage(prompt)
                        onNavigateToAssistant()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_ask_ai_checklist"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberCyan,
                        contentColor = Color(0xFF00364A)
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("AI-কে এই চেকলিস্ট এনালাইসিস করতে বলুন", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
