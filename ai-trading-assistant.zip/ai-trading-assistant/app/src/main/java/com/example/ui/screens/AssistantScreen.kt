package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.BearRed
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.TradingDarkBg
import com.example.ui.theme.TradingDarkCard
import com.example.ui.theme.TradingDarkSurface
import com.example.ui.theme.WarningGold
import com.example.ui.viewmodel.ChatMessage
import com.example.ui.viewmodel.MessageSender
import com.example.ui.viewmodel.TradingViewModel

@Composable
fun AssistantScreen(
    viewModel: TradingViewModel,
    onNavigateToMarket: () -> Unit
) {
    val context = LocalContext.current
    val messages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val isAnalyzing by viewModel.isAnalyzing.collectAsStateWithLifecycle()
    val pendingBitmap by viewModel.pendingChartBitmap.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()

    var inputText by remember { mutableStateOf("") }

    // Android Photo Picker (Compliant with Play Store policies)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let {
            try {
                val bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    val source = ImageDecoder.createSource(context.contentResolver, it)
                    ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                        decoder.isMutableRequired = true
                    }
                } else {
                    @Suppress("DEPRECATION")
                    MediaStore.Images.Media.getBitmap(context.contentResolver, it)
                }
                viewModel.setPendingChartBitmap(bitmap)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Auto-scroll when new messages arrive
    LaunchedEffect(messages.size, isAnalyzing) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TradingDarkBg)
    ) {
        // Assistant Header
        Surface(
            color = TradingDarkSurface,
            tonalElevation = 3.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(CyberCyan.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.AutoAwesome,
                            contentDescription = "AI Assistant",
                            tint = CyberCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "AI Trading Assistant",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "আপনার শেখানো নিয়ম অনুযায়ী চালিত",
                            fontSize = 11.sp,
                            color = BullGreen
                        )
                    }
                }

                IconButton(
                    onClick = { viewModel.clearChat() },
                    modifier = Modifier.testTag("btn_clear_chat")
                ) {
                    Icon(
                        Icons.Default.DeleteSweep,
                        contentDescription = "চ্যাট মুছুন",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Quick Analysis Prompts
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(TradingDarkSurface.copy(alpha = 0.5f))
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = false,
                onClick = {
                    viewModel.sendUserMessage("বর্তমান চার্ট ও মার্কেট ট্রেন্ড আমার শেখানো নিয়ম অনুযায়ী এনালাইসিস করে দিন।")
                },
                label = { Text("📊 ট্রেন্ড এনালাইসিস", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(labelColor = MaterialTheme.colorScheme.onSurface)
            )
            FilterChip(
                selected = false,
                onClick = {
                    viewModel.sendUserMessage("আমার শেখানো কনফ্লুয়েন্স রুলস অনুযায়ী পরবর্তী ক্যান্ডেলে ট্রেড নেওয়ার সুযোগ আছে কি?")
                },
                label = { Text("🔍 কনফ্লুয়েন্স চেক", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(labelColor = MaterialTheme.colorScheme.onSurface)
            )
            FilterChip(
                selected = false,
                onClick = {
                    viewModel.sendUserMessage("মার্কেট-qx.info তে OTC ট্রেড করার সময় কোন রিস্ক রুলস সবচেয়ে জরুরি?")
                },
                label = { Text("⚠️ রিস্ক রুলস", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(labelColor = MaterialTheme.colorScheme.onSurface)
            )
            FilterChip(
                selected = false,
                onClick = {
                    viewModel.sendUserMessage("ক্যান্ডেলস্টিক উইক রিজেকশন এবং সাপোর্ট-রেজিস্ট্যান্সের সেরা সেটআপ ব্যাখ্যা করুন।")
                },
                label = { Text("📈 S/R স্ট্র্যাটেজি", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(labelColor = MaterialTheme.colorScheme.onSurface)
            )
        }

        // Messages List
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                ChatMessageItem(message = msg)
            }

            if (isAnalyzing) {
                item {
                    AnalyzingIndicator()
                }
            }
        }

        // Pending Attachment Preview Banner
        AnimatedVisibility(visible = pendingBitmap != null) {
            pendingBitmap?.let { bmp ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = TradingDarkCard),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = "Attached Chart",
                                modifier = Modifier
                                    .size(50.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(1.dp, CyberCyan, RoundedCornerShape(8.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    "চার্ট সংযুক্ত হয়েছে (Market QX)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CyberCyan
                                )
                                Text(
                                    "প্রশ্ন বা রুলস লিখে সেন্ড চাপুন",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        IconButton(onClick = { viewModel.setPendingChartBitmap(null) }) {
                            Icon(Icons.Default.Close, contentDescription = "মুছুন", tint = BearRed)
                        }
                    }
                }
            }
        }

        // Bottom Chat Input Area
        Surface(
            color = TradingDarkSurface,
            tonalElevation = 6.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Attach Gallery Image button
                IconButton(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    modifier = Modifier
                        .size(44.dp)
                        .testTag("btn_attach_image")
                ) {
                    Icon(
                        Icons.Default.AddPhotoAlternate,
                        contentDescription = "চার্ট ছবি দিন",
                        tint = CyberCyan
                    )
                }

                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = {
                        Text(
                            "ট্রেডিং প্রশ্ন বা স্ট্র্যাটেজি রির্সাছ...",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 4.dp)
                        .testTag("input_chat_text"),
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberCyan,
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedContainerColor = Color(0xFF0B132B),
                        unfocusedContainerColor = Color(0xFF0B132B),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    maxLines = 4
                )

                // Send Button
                IconButton(
                    onClick = {
                        if (inputText.isNotBlank() || pendingBitmap != null) {
                            viewModel.sendUserMessage(inputText)
                            inputText = ""
                        }
                    },
                    enabled = !isAnalyzing && (inputText.isNotBlank() || pendingBitmap != null),
                    modifier = Modifier
                        .size(44.dp)
                        .testTag("btn_send_chat")
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                if (inputText.isNotBlank() || pendingBitmap != null) CyberCyan else Color(0xFF1E293B)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send",
                            tint = if (inputText.isNotBlank() || pendingBitmap != null) Color(0xFF00364A) else Color(0xFF64748B),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ChatMessageItem(message: ChatMessage) {
    val isUser = message.sender == MessageSender.USER

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Card(
            modifier = Modifier
                .widthIn(max = 340.dp)
                .padding(horizontal = 4.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isUser) Color(0xFF1E3A8A) else TradingDarkCard
            ),
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            )
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                // Attached image if any
                message.imageBitmap?.let { bmp ->
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = "Chart Screenshot",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // AI Signal Badge if present
                if (!isUser && message.signalType != null && message.signalType != "INSIGHT") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        val (bgColor, textColor, icon, label) = when (message.signalType) {
                            "CALL" -> listOf(BullGreen.copy(alpha = 0.2f), BullGreen, Icons.AutoMirrored.Filled.TrendingUp, "CALL / আপ ট্রেড")
                            "PUT" -> listOf(BearRed.copy(alpha = 0.2f), BearRed, Icons.AutoMirrored.Filled.TrendingDown, "PUT / ডাউন ট্রেড")
                            else -> listOf(WarningGold.copy(alpha = 0.2f), WarningGold, Icons.Default.Warning, "WAIT / অপেক্ষা করুন")
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(bgColor as Color)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                icon as androidx.compose.ui.graphics.vector.ImageVector,
                                contentDescription = null,
                                tint = textColor as Color,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = label as String,
                                color = textColor,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Confluence Meter
                        message.confluenceScore?.let { score ->
                            Text(
                                text = "$score% কনফ্লুয়েন্স",
                                color = if (score >= 75) BullGreen else WarningGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Text(
                    text = message.text,
                    fontSize = 13.sp,
                    lineHeight = 20.sp,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun AnalyzingIndicator() {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(TradingDarkCard)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CircularProgressIndicator(
            modifier = Modifier.size(16.dp),
            strokeWidth = 2.dp,
            color = CyberCyan
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = "আপনার শেখানো নিয়ম অনুযায়ী মার্কেট বিশ্লেষণ হচ্ছে...",
            fontSize = 12.sp,
            color = CyberCyan
        )
    }
}
