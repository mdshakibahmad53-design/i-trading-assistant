package com.example.ui.screens

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.TradingDarkCard
import com.example.ui.theme.TradingDarkSurface
import com.example.ui.viewmodel.TradingViewModel

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MarketBrowserScreen(
    viewModel: TradingViewModel,
    onNavigateToAssistant: () -> Unit
) {
    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var pageLoadingProgress by remember { mutableFloatStateOf(0f) }
    var isLoading by remember { mutableStateOf(true) }
    var currentUrl by remember { mutableStateOf("https://market-qx.info/en") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TradingDarkSurface)
    ) {
        // Top Trading Browser Bar
        Surface(
            color = TradingDarkCard,
            tonalElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { webViewInstance?.let { if (it.canGoBack()) it.goBack() } },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("btn_web_back")
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "পিছনে যান",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        IconButton(
                            onClick = { webViewInstance?.let { if (it.canGoForward()) it.goForward() } },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("btn_web_forward")
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = "সামনে যান",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        IconButton(
                            onClick = { webViewInstance?.reload() },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("btn_web_reload")
                        ) {
                            Icon(
                                Icons.Default.Refresh,
                                contentDescription = "রিলোড",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        // URL / Security indicator
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0xFF0F172A))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                Icons.Default.Lock,
                                contentDescription = "Secure",
                                tint = BullGreen,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "market-qx.info/en",
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    // Primary Action: Snap & Send to AI Assistant
                    Button(
                        onClick = {
                            webViewInstance?.let { wv ->
                                try {
                                    val width = wv.width.coerceAtLeast(1)
                                    val height = wv.height.coerceAtLeast(1)
                                    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                                    val canvas = Canvas(bitmap)
                                    wv.draw(canvas)
                                    viewModel.setPendingChartBitmap(bitmap)
                                    onNavigateToAssistant()
                                } catch (e: Exception) {
                                    // Fallback to navigating to assistant
                                    onNavigateToAssistant()
                                }
                            } ?: onNavigateToAssistant()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberCyan,
                            contentColor = Color(0xFF00364A)
                        ),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.testTag("btn_snap_chart")
                    ) {
                        Icon(
                            Icons.Default.CameraAlt,
                            contentDescription = "Snap Chart",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("চার্ট এনালাইসিস", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Quick Trading Shortcuts
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = false,
                        onClick = { webViewInstance?.loadUrl("https://market-qx.info/en") },
                        label = { Text("Quotex Home", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(labelColor = MaterialTheme.colorScheme.onSurface)
                    )
                    FilterChip(
                        selected = false,
                        onClick = { webViewInstance?.loadUrl("https://market-qx.info/en/sign-in") },
                        label = { Text("Sign In", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(labelColor = MaterialTheme.colorScheme.onSurface)
                    )
                    FilterChip(
                        selected = false,
                        onClick = { webViewInstance?.loadUrl("https://market-qx.info/en/trade") },
                        label = { Text("Live Trading", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(labelColor = MaterialTheme.colorScheme.onSurface)
                    )
                    FilterChip(
                        selected = false,
                        onClick = { webViewInstance?.loadUrl("https://market-qx.info/en/demo-trade") },
                        label = { Text("Demo Account", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(labelColor = MaterialTheme.colorScheme.onSurface)
                    )
                }
            }
        }

        // Loading bar
        if (isLoading) {
            LinearProgressIndicator(
                progress = { pageLoadingProgress },
                modifier = Modifier.fillMaxWidth(),
                color = CyberCyan,
                trackColor = Color.Transparent,
            )
        }

        // Embedded Browser for market-qx.info with Persistent Session
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            AndroidView(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("quotex_webview"),
                factory = { context ->
                    WebView(context).apply {
                        layoutParams = FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )

                        // Setup cookies for session & login persistence
                        val cookieManager = CookieManager.getInstance()
                        cookieManager.setAcceptCookie(true)
                        cookieManager.setAcceptThirdPartyCookies(this, true)

                        settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            useWideViewPort = true
                            loadWithOverviewMode = true
                            setSupportZoom(true)
                            builtInZoomControls = true
                            displayZoomControls = false
                            cacheMode = WebSettings.LOAD_DEFAULT
                            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                            userAgentString = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                        }

                        webViewClient = object : WebViewClient() {
                            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                super.onPageStarted(view, url, favicon)
                                isLoading = true
                                url?.let { currentUrl = it }
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                super.onPageFinished(view, url)
                                isLoading = false
                                CookieManager.getInstance().flush()
                            }
                        }

                        webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                super.onProgressChanged(view, newProgress)
                                pageLoadingProgress = newProgress / 100f
                                if (newProgress >= 100) {
                                    isLoading = false
                                }
                            }
                        }

                        loadUrl("https://market-qx.info/en")
                        webViewInstance = this
                    }
                },
                update = {
                    webViewInstance = it
                }
            )

            // Info Card Overlay at bottom for seamless guidance
            Card(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(8.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xDD0F172A)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Security,
                        contentDescription = "Session Security",
                        tint = BullGreen,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "আপনার অ্যাকাউন্ট লগইন ও সেশন সুরক্ষিত থাকে। চার্ট দেখে উপরে 'চার্ট এনালাইসিস' চাপুন।",
                        fontSize = 11.sp,
                        color = Color(0xFFE2E8F0)
                    )
                }
            }
        }
    }
}
